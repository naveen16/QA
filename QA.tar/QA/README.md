#Step 1:
cd QA
sqlite3 qadb.sqlite < db/db.sql
python app.py

#Step 2:
Open browser and point to:
http://localhost:5000/

#Step 3:
Click “Test QA Services” button to test all of the services. 
